package com.example.medicinefinderpharmacy;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class activity_login extends AppCompatActivity {

    TextView txt_create_account, txt_forgot_password;
    ListView list_item;
    ArrayList<String> city_name = new ArrayList<>();
    ArrayAdapter adapter;
    EditText edt_email_id,password;
    Button Btn_login;

    Dialog forgot_dialog;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        init();
    }
    void init() {

        forgot_dialog = new Dialog(activity_login.this, R.style.MyAlertDialogStyle);
        forgot_dialog.setContentView(R.layout.dialog_forgot_password);


        txt_create_account = findViewById(R.id.txt_create_account);
        txt_forgot_password = findViewById(R.id.txt_forgot_password);
        edt_email_id = findViewById(R.id.edt_email_id);
        password = findViewById(R.id.password);
        Btn_login = findViewById(R.id.Btn_login);


        adapter = new ArrayAdapter(activity_login.this, android.R.layout.simple_list_item_1, city_name);

        txt_create_account.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(activity_login.this, Signup.class));
            }
        });

        txt_forgot_password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                forgot_dialog.show();
            }
        });

        Btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validate_data();
            }
        });


    }

    void validate_data()
    {
        if(edt_email_id.getText().toString().equals(""))
        {
            edt_email_id.setError("Required filled");
        }
        else if (password.getText().toString().equals(""))
        {
            password.setError("Required filled");
        }
        else
        {
            Toast.makeText(this, "Done", Toast.LENGTH_SHORT).show();
        }

    }
}