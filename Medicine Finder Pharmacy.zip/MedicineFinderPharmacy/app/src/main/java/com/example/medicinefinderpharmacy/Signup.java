package com.example.medicinefinderpharmacy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class Signup extends AppCompatActivity {

    EditText edt_shopname, mobile_no, edt_Drug_license_No, Gst_In_No, Emailid, password, edt_Address, edt_State;
    Spinner city_spinner;
    Button btn_sign_up;
    TextView btn_back_login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        init();
    }

    void init() {

        mobile_no = findViewById(R.id.mobile_no);

        city_spinner = findViewById(R.id.city_spinner);
        edt_shopname = findViewById(R.id.edt_shopname);
        btn_sign_up = findViewById(R.id.btn_sign_up);
        btn_back_login = findViewById(R.id.btn_back_login);

        btn_sign_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Signup.this, city_spinner.getSelectedItem().toString(), Toast.LENGTH_SHORT).show();
            }
        });

        btn_back_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}